import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		StudentServiceImpl studentServiceImpl = new StudentServiceImpl();
		Scanner scanner = new Scanner(System.in);
		while (true) {
			studentServiceImpl.showMenu();
			int choose = scanner.nextInt();
			switch (choose) {
			case 1: {
				System.out.print("请输入name:");
				String name = scanner.next();
				System.out.print("请输入sex:");
				String sex = scanner.next();
				System.out.print("请输入age:");
				String age = scanner.next();
				System.out.print("请输入num:");
				String num = scanner.next();
				studentServiceImpl.add(new Student(name, sex, age, num));
				break;
			}
			case 2: {
				System.out.print("请输入num:");
				String num = scanner.next();
				Student s = studentServiceImpl.findStudentByNum(num);
				System.out.println("你查找的信息为:" + s);
				break;
			}
			case 3: {
				System.out.print("请输入num:");
				String num = scanner.next();
				studentServiceImpl.deleteStudentByNum(num);
				break;
			}
			case 4: {
				studentServiceImpl.printAllStudent();
				break;
			}
			case 5: {
				System.out.print("请输入num:");
				String num = scanner.next();
				studentServiceImpl.findStudentByNum(num);
				break;
			}
			case 6: {
				System.exit(0);
				break;
			}
			}
			System.out.println("按任意键继续,并回车！");
			scanner.next();
		}
	}

}

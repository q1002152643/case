public interface StudentService {
	void add(Student s);

	Student findStudentByNum(String num);

	void deleteStudentByNum(String num);

	void printAllStudent();

	void printStudentAtNum(String num);

	void showMenu();
}

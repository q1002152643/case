import java.util.ArrayList;
import java.util.List;

public class StudentServiceImpl implements StudentService {
	private List<Student> list = new ArrayList<Student>();

	public List<Student> getList() {
		return list;
	}

	public void setList(List<Student> list) {
		this.list = list;
	}

	@Override
	public void add(Student s) {
		if (s != null && !list.contains(s)) {
			list.add(s);
			System.out.println("添加成功!");
		} else {
			System.out.println("该生信息已存在，添加失败!");
		}

	}

	@Override
	public Student findStudentByNum(String num) {
		for (Student student : list) {
			if (student.getNum().equals(num)) {
				return student;
			}
		}
		return null;
	}

	@Override
	public void deleteStudentByNum(String num) {
		for (Student student : list) {
			if (student.getNum().equals(num)) {
				list.remove(student);
				System.out.println("成功删除!");
			} else {
				System.out.println("删除失败!");
			}
		}

	}

	@Override
	public void printAllStudent() {
		if (list.size() == 0)
			System.out.println("无信息存在！");
		for (Student student : list) {
			System.out.println(student);
		}

	}

	@Override
	public void printStudentAtNum(String num) {
		for (Student student : list) {
			if (student.getNum().equals(num)) {
				System.out.println(student);
			}
		}
	}

	@Override
	public void showMenu() {
		System.out.println("------------------------");
		System.out.println("学籍管理系统");
		System.out.println("------------------------");
		System.out.println("1.添加学生");
		System.out.println("2.查找学生");
		System.out.println("3.删除学生");
		System.out.println("4.显示所有学生");
		System.out.println("5.对指定学生的对象信息进行输出");
		System.out.println("6.退出");
		System.out.println(">>>");
		System.out.println(">>>请按数字键选择你的操作：");

	}

}
